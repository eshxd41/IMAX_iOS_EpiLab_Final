//
//  MainNavigationController.swift
//  IMAX
//
//  Created by Guest User on 04/01/18.
//  Copyright © 2018 suresh kumar YEDLA. All rights reserved.
//

import Foundation
import UIKit

class MainNavigationController : UINavigationController{
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
